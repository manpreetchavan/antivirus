Welcome to Our project
git push https://github.com/manpreetchavan/antivirus.git master:new_branch
git remote add origin https://github.com/manpreetchavan/antivirus.git
git config --global user.email "rushike.ab1@gmail.com"
git config --global user.name "rushike"